# Cellular RF Monitor

Install:
  bash install_cellmon.sh

Reload shell:
  source ~/.bashrc   # or source ~/.zshrc

Run:
  cellmon

Installer saves credentials to ~/.config/cellmon_config.json (600 perms).
